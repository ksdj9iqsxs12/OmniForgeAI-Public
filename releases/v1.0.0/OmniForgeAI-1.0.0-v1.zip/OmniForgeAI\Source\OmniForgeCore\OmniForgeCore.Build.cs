using System;
using UnrealBuildTool;

public class OmniForgeCore : ModuleRules
{
	private static string CppStringLiteral(string Value)
	{
		return (Value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"");
	}

	public OmniForgeCore(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
		CppStandard = CppStandardVersion.Cpp20;

		string BackendBaseUrl = Environment.GetEnvironmentVariable("OMNIFORGE_BACKEND_BASE_URL");
		if (string.IsNullOrWhiteSpace(BackendBaseUrl))
		{
			BackendBaseUrl = "https://api.omniforge.ai/plugin";
		}
		PublicDefinitions.Add($"OMNIFORGE_BACKEND_BASE_URL=TEXT(\"{CppStringLiteral(BackendBaseUrl)}\")");

		PublicDependencyModuleNames.AddRange(new[] {
			"Core", "CoreUObject", "Engine", "HTTP", "Json", "JsonUtilities",
			"Projects", "DeveloperSettings"
		});

		PrivateDependencyModuleNames.AddRange(new[] {
			"Slate", "SlateCore", "UnrealEd", "EditorSubsystem"
		});
	}
}
