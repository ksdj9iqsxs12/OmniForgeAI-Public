	using System.IO;
	using UnrealBuildTool;

	public class OmniForgeTools : ModuleRules
	{
		public OmniForgeTools(ReadOnlyTargetRules Target) : base(Target)
		{
			PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
			CppStandard = CppStandardVersion.Cpp20;

			var ToolsPublicPath = Path.Combine(ModuleDirectory, "Public", "Tools");
			if (Directory.Exists(ToolsPublicPath))
			{
				PublicIncludePaths.Add(ToolsPublicPath);
			}

		PublicDependencyModuleNames.AddRange(new[] {
			"Core", "CoreUObject", "Engine", "OmniForgeCore",
			"HTTP", "Json", "JsonUtilities", "BlueprintGraph", "Kismet", "KismetCompiler",
			"AssetRegistry", "AssetTools", "UnrealEd", "EditorScriptingUtilities", "RenderCore",
			"UMGEditor", "Niagara", "NiagaraEditor", "AIModule", "GameplayTasks", "Projects",
			"EnhancedInput", "InputCore"
		});

		PrivateDependencyModuleNames.AddRange(new[] {
			"Slate", "SlateCore", "LevelEditor", "EditorSubsystem",
			"GameplayTasksEditor", "UMG", "AnimGraph", "AnimGraphRuntime",
			"PythonScriptPlugin", "PhysicsUtilities", "IKRig", "IKRigEditor",
			"InputBlueprintNodes"
		});
		if (Target.Platform == UnrealTargetPlatform.Win64)
		{
			PrivateDependencyModuleNames.Add("LiveCoding");
		}
		}
	}
