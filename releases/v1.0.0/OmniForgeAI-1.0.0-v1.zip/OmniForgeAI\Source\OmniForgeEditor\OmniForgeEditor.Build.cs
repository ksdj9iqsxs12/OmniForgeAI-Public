	using System;
	using UnrealBuildTool;

	public class OmniForgeEditor : ModuleRules
	{
		public OmniForgeEditor(ReadOnlyTargetRules Target) : base(Target)
		{
			PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
			CppStandard = CppStandardVersion.Cpp20;

			PublicDependencyModuleNames.AddRange(new[] {
				"Core", "CoreUObject", "Engine", "OmniForgeCore", "OmniForgeTools",
				"Json", "JsonUtilities"
			});

		PrivateDependencyModuleNames.AddRange(new[] {
			"Slate", "SlateCore", "UnrealEd", "EditorSubsystem", "AppFramework",
			"LevelEditor", "WorkspaceMenuStructure", "ToolMenus", "InputCore",
			"Projects", "MainFrame", "ContentBrowser", "DeveloperSettings",
			"WebBrowser", "WebBrowserWidget", "HTTPServer", "HTTP"
		});

		if (Target.Platform == UnrealTargetPlatform.Win64)
		{
			AddEngineThirdPartyPrivateStaticDependencies(Target, "OpenSSL");
			PublicDefinitions.Add("OMNIFORGE_WITH_OPENSSL=1");
		}
		else
		{
			PublicDefinitions.Add("OMNIFORGE_WITH_OPENSSL=0");
		}

		string UpdatePublicKey = Environment.GetEnvironmentVariable("OMNIFORGE_UPDATE_SIGNING_PUBLIC_KEY_BASE64") ?? "";
		UpdatePublicKey = UpdatePublicKey.Replace("\\", "\\\\").Replace("\"", "\\\"");
		PublicDefinitions.Add($"OMNIFORGE_UPDATE_SIGNING_PUBLIC_KEY_BASE64=\"{UpdatePublicKey}\"");
		}
	}
